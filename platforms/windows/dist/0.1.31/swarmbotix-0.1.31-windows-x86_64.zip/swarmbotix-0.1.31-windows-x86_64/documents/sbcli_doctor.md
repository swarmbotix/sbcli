# `sb doctor` — Environment Validation Reference

Official reference for `sb doctor`: what it checks, what it considers
"OK" vs "FAIL" vs "SKIP", and how to read its output when something
about your host environment is wrong.

This document is normative for behavior shipped at L1. The canonical
schema source is still [requirements.md](../requirements.md); when the two
disagree, requirements.md wins. The CLAUDE.md "Key design decisions"
section in this repo summarizes the architectural choices that drive
the behavior below.

---

## 1. Conceptual model

`sb doctor` is a **read-only diagnostic**. It loads the merged
`sb.config.yml` (see [sbcli_config.md](sbcli_config.md) §3) and walks
a hard-coded checklist:

1. **Executables** — each declared tool path must exist on disk and
   answer to its version flag.
2. **Shared libraries** — each declared `.so` must exist and
   `dlopen` cleanly (the actual symbols aren't called).
3. **Message vault** — `<message_definitions>/std/` must contain the
   forge-bundled `.proto` files; offers to re-install on miss.

No state is written. No network calls. No build / compile happens.
Doctor is safe to run at any time, including during ongoing pub/sub
sessions.

The output is a fixed-format checklist; each line is one of:

```
[OK]   <name>       <details>
[FAIL] <name>       <reason>
[SKIP] <name>       <why skipped>
```

A FAIL line never aborts the run — doctor keeps going to surface
every problem in one pass (per L1 TDD test #10). The process exit
code is **0** only if every check is `[OK]` or `[SKIP]`; **non-zero**
on any `[FAIL]`. The non-zero exit prints a summary line:

```
N check(s) failed
```

---

## 2. The checklist

Order is stable; the L1 doctor implementation iterates a hard-coded
list. Each entry corresponds to one dependency.

| # | Check name | What's verified | What configures it |
|---|---|---|---|
| 1 | `protoc` | Executable exists; `<path> --version` exits 0 and prints a version. | `protoc:` in sb.config.yml |
| 2 | `flatc` | Same. | `flatc:` |
| 3 | `libzenohc` | File exists at path; `libloading::Library::new(<path>)` succeeds (dlopen). | `libzenohc:` |
| 4 | `libiceoryx2` | Same shape as libzenohc. | `libiceoryx2:` |
| 5 | `tmux` | Executable exists; `<path> -V` exits 0 (note: tmux uses `-V`, not `--version`). | `tmux:` |
| 6 | `message style` | Active style has a `message_definitions/` under the messages root; reports which other styles are on disk. | `messages_root:`, `message_style:`, `--style` |
| 7 | `std vault` | Walks `<message_definitions>/std/` and confirms the expected forge files are present (`Header.proto`, `String.proto`, `StringStamped.proto`, `Twist.proto`, ...). | `message_definitions:` (or its derived path) |

Checks 1–5 share the same structure (`CheckResult` from
`sb_doctor`). Checks 6 and 7 have their own logic because they don't run
a subprocess and aren't a `dlopen` — they inspect the on-disk style tree
and the bundled-vs-on-disk file set.

**Check 7 is style-aware.** `std/` ships in the `ros2` style, so for any
other active style there is no bundle to be missing and the check reports
the vault's message count instead of failing. Flagging its absence
everywhere would be a permanent false failure on `swarmbotix` and on
user-added styles.

### 2.1 The "not configured" path

Each of checks 1–5 reads its path from the merged config. If the
field is unset (`None` after merging), the check is **`[SKIP]`**, not
`[FAIL]`:

```
[SKIP] flatc        not set in sb.config.yml
```

Rationale: not every host needs every tool. A pure-Rust user with no
FlatBuffers consumers can leave `flatc:` unset and doctor stays
green. The downstream `sb message compile --fb` would still error
loudly when actually invoked (see [sbcli_messages.md](sbcli_messages.md)
§9.3).

The exit code treats SKIP as success — a doctor run with three
configured tools and two skipped exits 0. To make a missing tool a
hard error, set the field to a non-existent path:

```yaml
flatc: /not/installed
```

Then doctor reports `[FAIL] flatc /not/installed (file not found)`
and the run exits non-zero.

---

## 3. Output format

```
$ sb doctor
[OK]   protoc       /opt/protobuffer/protoc-35.0-linux-x86_64/bin/protoc (libprotoc 35.0)
[OK]   flatc        /opt/flatbuffers/Linux.flatc.binary.g++-13/flatc (flatc version 25.12.19)
[OK]   libzenohc    /opt/zenoh-c/current/lib/libzenohc.so (dlopen OK)
[OK]   libiceoryx2  /opt/iceoryx2/current/lib/libiceoryx2_ffi_c.so (dlopen OK)
[OK]   tmux         /usr/bin/tmux (tmux 3.4)
[OK]   message style ros2 @ /home/el/.swarmbotix/messages (also present: swarmbotix)
[OK]   std vault    /home/el/.swarmbotix/messages/ros2/message_definitions/std populated
```

On a non-ros2 style the last two lines read:

```
[OK]   message style swarmbotix @ /home/el/.swarmbotix/messages (also present: ros2)
[OK]   std vault    n/a for style swarmbotix — /home/el/.swarmbotix/messages/swarmbotix/message_definitions holds 0 message(s); std/ ships in the ros2 style
```

Field widths:

- Column 1: tag in brackets (`[OK]`, `[FAIL]`, `[SKIP]`), 6 chars wide.
- Column 2: check name, padded to 12 chars (`protoc`, `flatc`,
  `libzenohc`, `libiceoryx2`, `tmux`, `message style`, `std vault`).
- Column 3: free-form `<path> (<details>)` or `<reason>`.

Each line is one check. There is no header row, no totals line on
success, and no JSON / machine-readable mode (planned for L5).

### 3.1 Tag semantics

| Tag | Meaning | Exit-code impact |
|---|---|---|
| `[OK]` | Check ran, succeeded. | no |
| `[FAIL]` | Check ran, failed (file missing, dlopen error, subprocess non-zero). | yes — flips exit to non-zero |
| `[SKIP]` | Config field unset or check structurally inapplicable. | no |

There is no `[WARN]`. Every flagged condition is binary OK / FAIL.

---

## 4. Per-check details

### 4.1 `protoc`

```
[OK]   protoc       /opt/protobuffer/protoc-35.0-linux-x86_64/bin/protoc (libprotoc 35.0)
[FAIL] protoc       /usr/local/bin/protoc (file not found)
[FAIL] protoc       /tmp/dead/protoc (--version exited 127)
[SKIP] protoc       not set in sb.config.yml
```

Verification:

1. Read `cfg.protoc` (typed as `Option<PathBuf>`).
2. If `None` → `[SKIP]`.
3. If the file doesn't exist → `[FAIL]`.
4. Spawn `<path> --version`, capture stdout. If exit code != 0 →
   `[FAIL]` with the exit code.
5. On success, extract the first line of stdout (e.g. `libprotoc 35.0`)
   for the details column.

### 4.2 `flatc`

Same shape as `protoc`. The details column shows the first line of
`<path> --version`, typically `flatc version 25.12.19`.

### 4.3 `libzenohc`

```
[OK]   libzenohc    /opt/zenoh-c/current/lib/libzenohc.so (dlopen OK)
[FAIL] libzenohc    /opt/zenoh-c/current/lib/libzenohc.so (dlopen error: <message>)
```

Verification:

1. Read `cfg.libzenohc`. If `None` → `[SKIP]`.
2. If the file doesn't exist → `[FAIL]`.
3. `libloading::Library::new(path)` — load + immediately drop.
   No symbols are looked up; this only catches "the dynamic linker
   can't load this file at all" failures (typically: missing
   transitive deps, wrong architecture, GLIBC mismatch).

Possible failures dlopen catches:

- Missing transitive deps: `libssl.so.1.1: cannot open shared object
  file: No such file or directory`.
- Architecture mismatch: `wrong ELF class: ELFCLASS32` (32-bit lib
  against 64-bit host).
- GLIBC: `version GLIBC_2.34 not found`.

What dlopen does **not** catch:

- The library exists and loads but exports a stale ABI version.
  `sb doctor` does not call into Zenoh's `z_*` symbols to verify
  version match. The runtime check happens at pub/sub time.

### 4.4 `libiceoryx2`

Same shape as `libzenohc`. **Known mismatch on this dev box:** the
system `libiceoryx2_ffi_c.so` is v0.8.1 while the L3+ crate pin is
0.9. `dlopen` succeeds on both versions, so doctor stays green. The
ABI mismatch would only surface if doctor grew a "call a known symbol
and verify the version" step (not yet implemented).

### 4.5 `tmux`

```
[OK]   tmux         /usr/bin/tmux (tmux 3.4)
[FAIL] tmux         /usr/bin/tmux (-V exited 1)
```

Verification: same as protoc/flatc, but invokes `<path> -V` (note the
short flag — tmux's `--version` triggers help on some builds).
First line of stdout becomes the details column.

L5's `sb up` / `sb run` will require tmux at runtime; doctor's tmux
check is what tells you ahead of time whether those will work.

### 4.6 `std vault`

```
[OK]   std vault    /home/el/.swarmbotix/messages/ros2/message_definitions/std populated
[FAIL] std vault    /home/el/.swarmbotix/messages/ros2/message_definitions/std missing X expected file(s) (run `sb message list` to install)
```

Verification:

1. Resolve `<message_definitions>` (see [sbcli_messages.md](sbcli_messages.md) §1).
2. Walk `<message_definitions>/std/`.
3. For each file in the forge-bundled `STD_BUNDLE`
   (`Header.proto`, `String.proto`, `StringStamped.proto`,
   `Vector3.proto`, `Twist.proto`, `TwistStamped.proto`,
   `Image.proto`, `ImageStamped.proto`), confirm the file exists in
   the vault.
4. If any are missing → `[FAIL]` with the count + hint at
   `sb message list` (which auto-installs).

The `[FAIL]` here is **soft** in the sense that it's trivially
recoverable: `sb message list` triggers `Vault::ensure_installed`
which copies missing files from the binary's embedded `STD_BUNDLE`.
After that, doctor goes green.

User-edited std files survive: `ensure_installed` only writes
**missing** files (per L1 TDD test #5 — `install_preserves_user_edits`).
Doctor only checks existence, not byte-equality with the bundle, so a
hand-modified `std/Header.proto` is still `[OK]`.

---

## 5. Exit code and error reporting

```bash
$ sb doctor
[OK]   protoc       ...
[FAIL] flatc        /opt/flatc/dead (file not found)
[OK]   libzenohc    ...
[OK]   libiceoryx2  ...
[OK]   tmux         ...
[OK]   std vault    ...
error: 1 check(s) failed
$ echo $?
1
```

The error line goes to **stderr** (consistent with the rest of the
CLI). Stdout has the checklist; stderr has the summary. Pipe stdout
to a parser without losing the failure signal.

Multiple failures count separately:

```
error: 3 check(s) failed
```

There's no `--quiet` flag; doctor always prints the full checklist.
Wrap it for CI:

```bash
sb doctor > /dev/null || { echo "host needs setup"; exit 1; }
```

---

## 6. Examples

### 6.1 Fresh dev box, nothing configured

```
$ sb doctor
[SKIP] protoc       not set in sb.config.yml
[SKIP] flatc        not set in sb.config.yml
[SKIP] libzenohc    not set in sb.config.yml
[SKIP] libiceoryx2  not set in sb.config.yml
[SKIP] tmux         not set in sb.config.yml
[FAIL] std vault    /home/user/.swarmbotix/messages/ros2/message_definitions/std missing 8 expected file(s) (run `sb message list` to install)
error: 1 check(s) failed
```

Recovery: `sb message list` (auto-installs) + edit
`~/.swarmbotix/sb.config.yml` to point at the installed tools (see
[sbcli_config.md](sbcli_config.md) §6).

### 6.2 Fully-configured dev box

```
$ sb doctor
[OK]   protoc       /opt/protobuffer/protoc-35.0-linux-x86_64/bin/protoc (libprotoc 35.0)
[OK]   flatc        /opt/flatbuffers/Linux.flatc.binary.g++-13/flatc (flatc version 25.12.19)
[OK]   libzenohc    /opt/zenoh-c/current/lib/libzenohc.so (dlopen OK)
[OK]   libiceoryx2  /opt/iceoryx2/current/lib/libiceoryx2_ffi_c.so (dlopen OK)
[OK]   tmux         /usr/bin/tmux (tmux 3.4)
[OK]   std vault    /home/el/.swarmbotix/messages/ros2/message_definitions/std populated
```

Exit code 0. This is the expected steady state.

### 6.3 Tool moved or upgraded out from under sb.config.yml

```
$ sb doctor
[OK]   protoc       /opt/protoc/bin/protoc (libprotoc 35.0)
[FAIL] flatc        /opt/flatc-old/bin/flatc (file not found)
...
error: 1 check(s) failed
```

The `flatc:` entry still points at a directory the user deleted.
Fix:

```bash
sb config set flatc /opt/flatc-new/bin/flatc
sb doctor
```

### 6.4 Loadable file but ABI is wrong (silent)

```
$ sb doctor
[OK]   libiceoryx2  /opt/iceoryx2/current/lib/libiceoryx2_ffi_c.so (dlopen OK)
```

Doctor passes even though the system `.so` is v0.8.1 while crate
consumers pin 0.9. Mismatch surfaces only at the L4+ iceoryx2-FFI
call sites. The plan-doc carries this caveat as a known gap.

### 6.5 CI gating

```yaml
- name: Validate host
  run: sb doctor

- name: Build
  run: cargo build --release
```

Doctor's non-zero exit fails CI early with a clear list of what's
wrong, before the multi-minute Rust build kicks off.

---

## 7. Configuration interactions

Doctor reads the **merged** config (env override → workspace →
global → built-in defaults), same as every other verb. To diagnose
which file populated each field:

```bash
SB_CONFIG=/tmp/scratch.yml sb doctor      # uses /tmp/scratch.yml as the highest-priority layer
```

vs.

```bash
sb doctor                                  # only the global ~/.swarmbotix/sb.config.yml
```

There's currently no `sb doctor --explain` mode that prints the
source-of-each-field. The layering is documented in
[sbcli_config.md](sbcli_config.md) §3 and the
`sb_config::ConfigSources` type tracks it internally; that data just
isn't surfaced through doctor's output yet.

---

## 8. What doctor doesn't check

By design (the L1 spec) doctor only validates the tooling that L1+
sb itself shells out to. Not validated:

- **Rust toolchain.** Cargo's own checks run when the user's project
  builds. sb itself is a single binary; the user's Rust toolchain
  isn't on the critical path for `sb` to function.
- **Python interpreter / packages.** `sb message new` doesn't shell
  out to Python; doctor doesn't either. The L3 examples activate
  conda explicitly. A `sb doctor` flag to check
  `pip show eclipse-zenoh` is planned but not shipped.
- **Flutter / Dart toolchain.** Same.
- **Network connectivity.** Zenoh's runtime discovery needs the
  network; doctor never opens a Zenoh session.
- **Shared-memory permissions.** iceoryx2's runtime needs
  `/dev/shm` writability; doctor doesn't probe.
- **Generated code freshness.** Doctor doesn't compare
  `<targets>/` mtimes against `<defs>/` mtimes. Use
  `sb message compile` to refresh.
- **`flow.yaml` referential integrity.** Doctor doesn't check that
  every entry in every workspace's `flow.yaml` points at an
  existing `sb.dev.yml`. That's a swarmctl concern (L6).

---

## 9. Edge cases and gotchas

### 9.1 tmux's `-V` quirk

The first L1 implementation used `--version` for tmux; that triggered
the help text on older tmux builds and the version-extraction regex
failed. The L1 report notes this caught during the first end-to-end
run; the fix (using `-V`) is locked in by
[level1_doctor_happy_and_failures.rs](../crates/sb-cli/tests/).

### 9.2 First-line stdout assumption

Doctor extracts the first line of `<tool> --version`'s stdout as the
details column. Tools that print a banner before the version (rare)
would show the banner instead. None of the L1-required tools do
this, but if you swap in an exotic protoc / flatc fork, the column
might look odd. No correctness issue — exit code still reflects
truth.

### 9.3 Tool path with spaces

`Command::new(<path>)` accepts paths with spaces, but the details
column's free-form formatting may look strange:

```
[OK]   protoc       /home/user/With Spaces/bin/protoc (libprotoc 35.0)
```

Cosmetic only; the check itself is fine.

### 9.4 `libloading` dlopen errors are sometimes terse

Some platforms return only "image not found" on dlopen failure, even
when the file does exist (e.g. when transitive deps are missing).
The details column reproduces what libloading gives us — debugging
might need `ldd <path>` to see the actual missing deps.

### 9.5 std vault check predates fresh-install

If `<sb_home>` is brand-new and you've never run any `sb` command,
`<message_definitions>/std/` doesn't exist yet. The std-vault check
reports the miss. Either run `sb message list` (which installs) or
just run `sb doctor` again — it has no install side effect on its
own, only the diagnostic.

### 9.6 No retry / sleep / network probe

Doctor runs each check **once**, synchronously, with no retries.
Transient errors (a tool whose binary is paged out mid-`--version`,
extremely rare) would surface as a one-off FAIL. Re-run if you
suspect noise.
