# `sb doctor` — Environment Validation Reference

Official reference for `sb doctor`: what it checks, what it considers
"OK" vs "FAIL" vs "SKIP", and how to read its output when something
about your host environment is wrong.

This document is normative for behavior shipped at L1.

The canonical spec is `requirements.md` in the sbcli **source
repository** — a maintainer document that is not part of your install;
when it and this page disagree, it wins.

---

## 1. Conceptual model

`sb doctor` is a **read-only diagnostic**. It loads the merged
`sb.config.yml` (see [sbcli_config.md](sbcli_config.md) §3) and walks
a hard-coded checklist:

1. **Executables** — each declared tool path must exist on disk and
   answer to its version flag.
2. **Transports** — the zenoh / iceoryx2 crate versions this `sb` was
   built against, reported so the libraries below have something to be
   compared with.
3. **Shared libraries** — each declared `.so` must exist and
   `dlopen` cleanly (the actual symbols aren't called), and its version
   is read off the install and checked against the linked crate.
4. **Message vault** — `<message_definitions>/std/` must contain the
   forge-bundled `.proto` files; offers to re-install on miss.
5. **Workspace topics** (sb 0.5.0+): pub/sub entries in the active
   workspace's modules that still use the pre-0.5.0 `topic: /...`
   spelling.
6. **Workspace** (sb 0.5.0+): the `sb ws check` validation rows for the
   active workspace (module files, message types, instance ids,
   encodings per wire key, generated io files, staleness, and, sb
   0.6.0+, required tools, platform support, wires, and leftover
   pre-0.6.0 files, which sb 0.7.0+ ignores).

No state is written. No network calls. No build / compile happens.
Doctor is safe to run at any time, including during ongoing pub/sub
sessions.

The output is a fixed-format checklist; each line is one of:

```
[OK]   <name>       <details>
[FAIL] <name>       <reason>
[SKIP] <name>       <why skipped>
```

A FAIL line never aborts the run — doctor keeps going to surface
every problem in one pass (per L1 TDD test #10). The process exit
code is **0** only if every check is `[OK]` or `[SKIP]`; **non-zero**
on any `[FAIL]`. The non-zero exit prints a summary line:

```
N check(s) failed
```

---

## 2. The checklist

Order is stable; the L1 doctor implementation iterates a hard-coded
list. Each entry corresponds to one dependency.

| # | Check name | What's verified | What configures it |
|---|---|---|---|
| 1 | `protoc` | Executable exists; `<path> --version` exits 0 and prints a version. | `protoc:` in sb.config.yml |
| 2 | `flatc` | Same. | `flatc:` |
| 3 | `transports` | States the zenoh / iceoryx2 crate versions compiled into this `sb`. Reports a property of the binary, so it is **always `[OK]`** and reads nothing from the config. | nothing — fixed at build time |
| 4 | `libzenohc` | File exists at path; `libloading::Library::new(<path>)` succeeds (dlopen); the install's own version is read and compared with the linked zenoh crate (major.minor). | `libzenohc:` |
| 5 | `libiceoryx2` | Same shape as libzenohc, but compared on **every digit** — iceoryx2 opens shared-memory segments on exact version equality. | `libiceoryx2:` |
| 6 | `tmux` | Executable exists; `<path> -V` exits 0 (note: tmux uses `-V`, not `--version`). | `tmux:` |
| 7 | `message styles` | Lists **every** style under the messages root — one row each with its message count and whether its bindings are built. No style is marked "active": there is no such thing. Fails only when the root holds no styles at all. | `messages_root:` |
| 8 | `unity targets` | Scans each style's `message_targets/` that sits inside a Unity project and counts generated `.cs` files a current `sb` would not have written. **Warns, never fails** — the breakage is in the host project, not in `sb`. | `messages_root:` |
| 9 | `config keys` | Reports `message_style` / `message_definitions` / `message_targets` if still present. They parse but do nothing, which is the combination that silently misleads. | any stale `sb.config.yml` |
| 10 | `std vault` | Walks `<messages_root>/ros2/message_definitions/std/` and confirms the expected forge files are present. Always the ros2 style — that is where `std/` lives. | `messages_root:` |
| 11 | `topics` | Scans the modules registered in the active workspace for publisher / subscriber entries still written as `topic: /<wire key>` (sb 0.5.0+). One `[WARN]` per offending module. **Warns, never fails**: such an entry is read as `key:` and works unchanged. `[SKIP]` with no active workspace. Details in §4.10. | the active workspace's `sb.flow.yaml` and its modules' manifests |
| 12 | `workspace`, `ws *`, `deprecated` | The `sb ws check` rows for the active workspace (sb 0.5.0+): `workspace` (summary), `ws modules`, `ws types`, `ws instances`, `ws encoding` (each `[FAIL]` per problem), `ws io files` (`[WARN]`), then (sb 0.6.0+) `ws requires` (`[FAIL]`), `ws platforms` (`[WARN]`), `ws wires` (`[FAIL]`), `deprecated` (`[WARN]`), and last `ws source` (`[WARN]`). A `[FAIL]` here **fails doctor**: it breaks `sb up` or codegen. `[SKIP] workspace` with no active workspace. Details in §4.11. | the active workspace's installed `sb.flow.yaml` (and through its `source:` the repo copy), its modules' `sb.module.yaml`, the configured vault, `PATH` |
| 13 | `app` | One line per installed app package (`sb 0.2.1+`): its kind, whether its folder still exists, and whether each binary in its `requires` list is on `PATH`. **Warns, never fails**, and prints nothing when no apps are installed. Details in [sbcli_app.md](sbcli_app.md) §9. | `<sb_home>/apps.yml` |

Checks 1, 2, 4, 5 and 6 share the same structure (`CheckResult` from
`sb_doctor`). Checks 7, 8 and 9 have their own logic because they don't
run a subprocess and aren't a `dlopen` — they inspect the on-disk style
tree, the generated C# in it, and the config as parsed. Check 3 touches
neither the config nor the disk: its two numbers are baked into the
binary when it is built (§4.9). Checks 11 and 12 read the active
workspace, not the host's tooling (§4.10, §4.11).

**Check 10 always looks at ros2.** `std/` ships there and the embedded
bundle installs there, so the check is not affected by what anyone happens
to be working on — nothing is "currently selected" any more.

### 2.1 The "not configured" path

Each of the path-reading checks — `protoc`, `flatc`, `libzenohc`,
`libiceoryx2`, `tmux` — takes its path from the merged config. If the
field is unset (`None` after merging), the check is **`[SKIP]`**, not
`[FAIL]`:

```
[SKIP] flatc        not set in sb.config.yml
```

Rationale: not every host needs every tool. A pure-Rust user with no
FlatBuffers consumers can leave `flatc:` unset and doctor stays
green. The downstream `sb message compile --fb` would still error
loudly when actually invoked (see [sbcli_messages.md](sbcli_messages.md)
§9.3).

The exit code treats SKIP as success — a doctor run with three
configured tools and two skipped exits 0. To make a missing tool a
hard error, set the field to a non-existent path:

```yaml
flatc: /not/installed
```

Then doctor reports `[FAIL] flatc /not/installed (file not found)`
and the run exits non-zero.

---

## 3. Output format

```
$ sb doctor
sb <version>
[OK]   protoc       /opt/protobuffer/protoc-35.0-linux-x86_64/bin/protoc (libprotoc 35.0)
[OK]   flatc        /opt/flatbuffers/Linux.flatc.binary.g++-13/flatc (flatc version 25.12.19)
[OK]   transports   zenoh 1.9.0, iceoryx2 0.9.3 (linked into this sb)
[OK]   libzenohc    /opt/zenoh-c/current/lib/libzenohc.so (v1.9.0, dlopen OK)
[OK]   libiceoryx2  /opt/iceoryx2/current/lib/libiceoryx2_ffi_c.so (v0.9.3, dlopen OK)
[OK]   tmux         /usr/bin/tmux (tmux 3.4)
[OK]   message styles /home/el/.swarmbotix/messages
                    ros2         138 msg  targets built
                    swarmbotix    14 msg  targets built
[OK]   unity targets no stale generated C# in a Unity tree
[OK]   config keys  no deprecated keys
[OK]   std vault    /home/el/.swarmbotix/messages/ros2/message_definitions/std populated
[OK]   topics       no legacy `topic: /...` entries in the active workspace
```

`sb 0.5.0+` follows the `topics` row with the workspace rows (§4.11);
the four rows between `ws io files` and `ws source` are `sb 0.6.0+`:

```
[OK]   workspace    ws_ips: 2 module(s), installed from https://github.com/acme/ws_ips.git
[OK]   ws modules   2 module(s), every module manifest parses
[OK]   ws types     3 typed entries resolve in the vault
[OK]   ws instances 0 instance(s), ids unique per module
[OK]   ws encoding  3 wire key(s), encodings agree
[OK]   ws io files  4 generated file(s) present
[OK]   ws requires  all required tools present
[OK]   ws platforms all modules support this host
[OK]   ws wires     no wires
[OK]   deprecated   nothing deprecated in use
[OK]   ws source    installed copy is current with /home/el/ws_ips/sb.flow.yaml
```

Three rows carry versions, and they are three different facts. `transports`
is what this binary links; the two `lib*` rows are what the installs on this
box are. While all three agree, `sb` and generated C/C++ consumers speak the
same protocol; when they diverge, the `lib*` row says so (§4.3, §4.4).

Every style is listed and none is marked "active" — there is no such
state. A style whose bindings were never generated says so and names the
fix; that is otherwise invisible until someone references one of its
messages and codegen fails against a missing target tree:

```
                    swarmbotix    14 msg  NOT COMPILED — run `sb message compile --style swarmbotix`
```

A config still carrying the dead keys:

```
[FAIL] config keys  message_style, message_targets set but IGNORED — message
                    names are fully qualified now (<style>/<namespace>/<Leaf>),
                    so there is no active style to select. Delete the line(s)
                    from sb.config.yml.
```

Field widths:

- Line 1 is not a check: `sb doctor` prints `sb <version>` — the literal
  string `sb ` followed by the same `CARGO_PKG_VERSION` that
  `sb --version` reports — before the checklist. Skip it when parsing.
  (`sb --version` itself may add a second `update available` line, see
  [sbcli_update.md](sbcli_update.md) §2; `sb doctor` never does.)
  (It is written as a placeholder here on purpose: this document does
  not mirror the current release number.)
- Column 1: tag in brackets (`[OK]`, `[FAIL]`, `[SKIP]`, `[WARN]`),
  6 chars wide.
- Column 2: check name, padded to 12 chars (`protoc`, `flatc`,
  `transports`, `libzenohc`, `libiceoryx2`, `tmux`, `message styles`,
  `unity targets`, `config keys`, `std vault`, `topics`, and sb 0.5.0+
  `workspace`, `ws modules`, `ws types`, `ws instances`, `ws encoding`,
  `ws io files`, `ws source`, and sb 0.6.0+ `ws requires`,
  `ws platforms`, `ws wires`, `deprecated`). Two names overflow that pad and push
  column 3 to the right — `message styles` (14) and `unity targets`
  (13). Do not align a parser on a fixed column offset.
- Column 3: free-form `<path> (<details>)` or `<reason>`. Continuation
  lines are indented 20 spaces to sit under column 3.

Each line after the version is one check. There is no header row, no
totals line on success, and no JSON / machine-readable mode.

Tags are **colored** (green / red / yellow, bold) when stdout is a TTY.
Redirecting to a file or a pipe, or setting a non-empty `NO_COLOR`,
emits plain ASCII — so the shapes quoted here are exactly what a script
sees.

### 3.1 Tag semantics

| Tag | Meaning | Exit-code impact |
|---|---|---|
| `[OK]` | Check ran, succeeded. | no |
| `[FAIL]` | Check ran, failed (file missing, dlopen error, subprocess non-zero). | yes — flips exit to non-zero |
| `[SKIP]` | Config field unset or check structurally inapplicable. | no |
| `[WARN]` | Something is wrong, but in the **host project** rather than in `sb`. | no |

Only `[FAIL]` moves the exit code: `Report::all_ok()` is "no check
failed", so a run of nothing but `[OK]`, `[SKIP]` and `[WARN]` exits 0.

`[WARN]` exists for these situations today: stale generated C# under a
Unity tree (§4.7), a native transport library whose version differs
from the crate `sb` links (§4.3, §4.4), and (sb 0.5.0+) legacy
`topic: /...` entries in the active workspace (§4.10), missing
generated io files or a stale installed copy in the active workspace,
and (sb 0.6.0+) a module that does not support this host or a
leftover pre-0.6.0 file, ignored since 0.7.0 (§4.11). The first two
break a *host* project rather than `sb`; the third breaks nothing, since
`sb` reads such an entry as `key:`, but flags a file the next `sb io`
write will rewrite. Failing there would block every unrelated `sb doctor`
on the box until someone fixed a tree `sb` does not own; staying silent
is what let the breakage accumulate in the first place. If you want
warnings to be fatal in CI, grep for the tag:

```bash
sb doctor | grep -q '^\[WARN\]' && exit 1
```

---

## 4. Per-check details

### 4.1 `protoc`

```
[OK]   protoc       /opt/protobuffer/protoc-35.0-linux-x86_64/bin/protoc (libprotoc 35.0)
[FAIL] protoc       /usr/local/bin/protoc (file not found)
[FAIL] protoc       /tmp/dead/protoc (--version exited 127)
[SKIP] protoc       not set in sb.config.yml
```

Verification:

1. Read `cfg.protoc` (typed as `Option<PathBuf>`).
2. If `None` → `[SKIP]`.
3. If the file doesn't exist → `[FAIL]`.
4. Spawn `<path> --version`, capture stdout. If exit code != 0 →
   `[FAIL]` with the exit code.
5. On success, extract the first line of stdout (e.g. `libprotoc 35.0`)
   for the details column.

### 4.2 `flatc`

Same shape as `protoc`. The details column shows the first line of
`<path> --version`, typically `flatc version 25.12.19`.

### 4.3 `libzenohc`

```
[OK]   libzenohc    /opt/zenoh-c/current/lib/libzenohc.so (v1.9.0, dlopen OK)
[OK]   libzenohc    /opt/local/lib/libzenohc.so (version unknown, dlopen OK)
[WARN] libzenohc    /opt/zenoh-c/1.8.4/lib/libzenohc.so (v1.8.4, dlopen OK)
                    sb links zenoh 1.9.0, this library is 1.8.4.
                    Patch releases interoperate; a differing major.minor is not guaranteed to.
                    Fix: sb config set libzenohc <path to a 1.9.0 install>
[FAIL] libzenohc    /opt/zenoh-c/current/lib/libzenohc.so (dlopen error: <message>)
```

Verification:

1. Read `cfg.libzenohc`. If `None` → `[SKIP]`.
2. If the file doesn't exist → `[FAIL]`.
3. `libloading::Library::new(path)` — load + immediately drop.
   No symbols are looked up; this only catches "the dynamic linker
   can't load this file at all" failures (typically: missing
   transitive deps, wrong architecture, GLIBC mismatch).
4. Determine the install's version (below), print it, and compare it
   with the zenoh crate from §4.9. Zenoh keeps patch releases
   wire-compatible, so only a differing **major.minor** warns.

Possible failures dlopen catches:

- Missing transitive deps: `libssl.so.1.1: cannot open shared object
  file: No such file or directory`.
- Architecture mismatch: `wrong ELF class: ELFCLASS32` (32-bit lib
  against 64-bit host).
- GLIBC: `version GLIBC_2.34 not found`.

**Where the version comes from.** Neither transport library exports a
version symbol, so there is nothing to call. What the installs do carry
is metadata beside the binary and a version in the path, and doctor
reads them in this order, first hit winning:

1. `<libdir>/pkgconfig/*.pc` → the `Version:` field.
2. `<libdir>/cmake/<pkg>/*ConfigVersion.cmake` → `set(PACKAGE_VERSION "…")`.
3. A `vX.Y.Z` / `X.Y.Z` component of the **canonical** path — the config
   normally points through a `current` symlink, which is resolved first
   so the version it hides becomes visible.
4. A `libfoo.so.X.Y.Z` filename suffix.

An install that states its version nowhere prints `version unknown` and
is never warned about: a number that could only be guessed at should not
be reported as if it had been measured.

What this still does **not** catch:

- A library that loads and reports a matching version but was built with
  incompatible options. Only the runtime pub/sub path proves that.

### 4.4 `libiceoryx2`

Same shape as `libzenohc`, with one difference that matters: the
comparison is on **every digit**, not just major.minor.

```
[WARN] libiceoryx2  /opt/iceoryx2/v0.9.0/lib/libiceoryx2_ffi_c.so (v0.9.0, dlopen OK)
                    sb links iceoryx2 0.9.3, this library is 0.9.0.
                    Segments are opened on exact version equality, so C/C++ consumers built
                    against this library will get VersionMismatch and an empty topic list.
                    Fix: sb config set libiceoryx2 <path to a 0.9.3 install>
```

iceoryx2 writes its full `major.minor.patch` into every shared-memory
segment and compares for equality when opening one. A 0.9.0 process
cannot see a service created by a 0.9.3 process: it gets
`VersionMismatch`, and `sb topic list` prints `(no topics)` against a
publisher that is very much alive. That is why a patch difference is
worth a warning here and not on zenoh.

The warning is not fatal — `sb` itself links the crate and keeps
working. What breaks is the generated C/C++ code a host project builds
against this library. Align the two by pointing `libiceoryx2` at the
matching install (`sb config set libiceoryx2 <path>`), or by rebuilding
`sb` against the version the box has.

### 4.5 `tmux`

```
[OK]   tmux         /usr/bin/tmux (tmux 3.4)
[FAIL] tmux         /usr/bin/tmux (-V exited 1)
```

Verification: same as protoc/flatc, but invokes `<path> -V` (note the
short flag — tmux's `--version` triggers help on some builds).
First line of stdout becomes the details column.

`sb up` / `sb run` require tmux at runtime; doctor's tmux check is
what tells you ahead of time whether those will work. On Windows the
same row finds psmux, which installs as `tmux`
([sbcli_launch.md](sbcli_launch.md) §11).

### 4.6 `std vault`

```
[OK]   std vault    /home/el/.swarmbotix/messages/ros2/message_definitions/std populated
[FAIL] std vault    /home/el/.swarmbotix/messages/ros2/message_definitions/std missing X expected file(s) (run `sb message list` to install)
[FAIL] std vault    /home/el/.swarmbotix/messages/ros2/message_definitions/std not found (run `sb message list` to install the bundle)
[SKIP] std vault    /home/dev/proj/messages has no ros2 style — std bundle lives in the configured vault, not a discovered one
```

The `[SKIP]` variant fires only when the vault was **discovered from
cwd** (§4.8) and has no `ros2` style at all. A standalone message repo
legitimately has none, and the forge bundle installs into the configured
vault only, so failing there would flag every such repo for doing
nothing wrong. Against the configured vault a missing `std/` is still a
hard `[FAIL]`.

Verification:

1. Resolve `<message_definitions>` (see [sbcli_messages.md](sbcli_messages.md) §1).
2. Walk `<message_definitions>/std/`.
3. For each file in the forge-bundled `STD_BUNDLE`
   (`Header.proto`, `String.proto`, `StringStamped.proto`,
   `Vector3.proto`, `Twist.proto`, `TwistStamped.proto`,
   `Image.proto`, `ImageStamped.proto`), confirm the file exists in
   the vault.
4. If any are missing → `[FAIL]` with the count + hint at
   `sb message list` (which auto-installs).

The `[FAIL]` here is **soft** in the sense that it's trivially
recoverable: `sb message list` triggers `Vault::ensure_installed`
which copies missing files from the binary's embedded `STD_BUNDLE`.
After that, doctor goes green.

User-edited std files survive: `ensure_installed` only writes
**missing** files (per L1 TDD test #5 — `install_preserves_user_edits`).
Doctor only checks existence, not byte-equality with the bundle, so a
hand-modified `std/Header.proto` is still `[OK]`.

### 4.7 `unity targets`

```
[OK]   unity targets no stale generated C# in a Unity tree
```

```
[WARN] unity targets generated C# Unity cannot compile:
                    swarmbotix: 12 generated .cs file(s) predate the current emitter
                      /path/to/UnityProj/Assets/Scripts/messages/swarmbotix/message_targets
                    File-scoped namespaces (C# 10) / [InlineArray] (.NET 8); Unity caps at C# 9.
                    Or an inline `_Array<N>` wrapper, which collides once two messages share
                    an element type (CS0101). Wrappers now live in iox2/_arrays/.
                    Fix: re-run `sb message compile` — the emitter handles both now.
                    These trees are usually committed, so commit the regenerated files too.
```

**This check never fails the run** (§3.1). What it finds is broken code
in a *user's Unity project*, not a broken `sb` install; making it fatal
would block every unrelated `sb doctor` on the box until somebody
cleaned up a tree `sb` does not own.

Verification, per style:

1. Resolve that style's `message_targets/`.
2. Walk **up** from it looking for a directory containing both
   `Assets/` and `ProjectSettings/`. No such ancestor → the tree is not
   inside a Unity project, and the style is skipped entirely.
3. Recursively count `.cs` files under `message_targets/` that a current
   `sb` would not have written — any file with a **file-scoped namespace**
   (`namespace Foo;`, C# 10), a `[InlineArray]` attribute (.NET 8), or an
   inline `_Array<N>` wrapper struct declared outside `iox2/_arrays/`.
4. Any offenders → one `[WARN]` naming each style, its count, and the
   path.

Why these three shapes: the emitter targets **C# 9 / .NET Standard 2.1**
so its output compiles inside Unity, but fixing the emitter does not
rewrite files already on disk — only a recompile does. File-scoped
namespaces raise `error CS8773` in Unity; `[InlineArray]` needs .NET 8;
and the pre-0.1.39 inline array wrapper declared one struct per message
file, which becomes `error CS0101` the moment two messages share an
element type (wrappers now live once each in `iox2/_arrays/`).

Detection is by **file content**, not by directory name, so it stays
accurate no matter which backends a style emits. The fix is always the
same: re-run `sb message compile`, then commit the regenerated files —
these trees are normally checked in.

Note that `sb` emits **all** backends into every tree, Unity included;
it does not narrow the backend set to suit one consumer. See
[sbcli_messages.md](sbcli_messages.md) §4.5 (backend selection) and
§5.1.

### 4.8 `message styles` — and which vault doctor is describing

```
[OK]   message styles /home/el/.swarmbotix/messages
                    ros2         138 msg  targets built
                    swarmbotix    14 msg  targets built
```

One row per style under the resolved root: its name, its `.proto` count,
and whether its `message_targets/` holds anything. Three per-style
states:

| State | Means |
|---|---|
| `targets built` | `message_targets/` is non-empty |
| ``NOT COMPILED — run `sb message compile --style <name>` `` | definitions exist, nothing generated |
| `no definitions` | the style directory exists but holds no `.proto` |

The only failure is a root with **no styles at all** — the one state
that makes `sb message` and `sb io` unusable:

```
[FAIL] message styles no styles found under /home/el/.swarmbotix/messages
```

**Doctor reports the vault the next command will actually use.** `sb`
walks up from the current directory looking for a `messages/` tree, and
a discovered tree beats `messages_root` from config
([sbcli_messages.md](sbcli_messages.md) §1). A doctor describing a
different tree than `sb message compile` is about to touch would be
worse than no doctor, so the check follows the same resolution and
**says so in the output**:

```
[OK]   message styles /home/dev/proj/messages (discovered from cwd — overrides `messages_root`)
```

And when cwd *is* itself a style directory, only that style is in scope:

```
[OK]   message styles /home/dev/proj/messages
                    cwd is the `swarmbotix` style — only it is in scope
                    swarmbotix    14 msg  targets built
```

Two consequences worth internalizing:

- **Run `sb doctor` from `$HOME`** (or with `$SB_CONFIG` set, which
  disables the walk) when you want a report about the configured
  install rather than about whatever checkout you happen to be sitting
  in.
- `std vault` (§4.6) **skips instead of failing** when a discovered root
  has no `ros2` style. A standalone message repo legitimately has no
  `std/`; the forge bundle installs into the configured vault only.

### 4.9 `transports`

```
[OK]   transports   zenoh 1.9.0, iceoryx2 0.9.3 (linked into this sb)
```

The two numbers are the zenoh and iceoryx2 **crates statically linked
into this binary**, fixed when `sb` was built. They are not read from
the config, cannot be changed by editing anything on the box, and are
not affected by which native libraries are installed.

This row exists so the `lib*` rows have something to be compared with.
On its own it answers "which transport versions does this `sb` speak",
a question that previously had no answer short of consulting the source
of the release it came from.

The row never fails. Its values are read out of the source repository's
lockfile when the binary is compiled, so they are exact by construction
rather than transcribed. A binary built outside that tree has nothing to
read and says so:

```
[OK]   transports   linked crate versions unavailable (built without Cargo.lock)
```

Official releases are always built in-tree, so this line should not
appear in an installed `sb`; if it does, the build did not come from the
release procedure and the two `lib*` rows will not be version-checked.

### 4.10 `topics` (sb 0.5.0+)

```
[OK]   topics       no legacy `topic: /...` entries in the active workspace
[SKIP] topics       no active workspace
```

Scans the modules registered in the active workspace's `sb.flow.yaml` for
publisher and subscriber entries still written in the pre-0.5.0 form
`topic: /<wire key>`. Since 0.5.0 the canonical topic has no leading
`/`, and an entry carries either `topic: <bare>` or `key: <wire key>`.
A legacy entry is read as `key: <wire key>` with the `/` dropped, which
is the wire key it always produced, so nothing is broken; the row exists
so the old spelling is rewritten before someone copies it into a new
entry. See [sbcli_pubsub.md](sbcli_pubsub.md) §13.9.

Each module that holds legacy entries gets one `[WARN] topics` row
naming the module and its manifest, then a continuation line per
entry with its role, name, the legacy `topic:` form, and its `key:`
equivalent, and finally the command that rewrites the file
(sb 0.7.0+: `sb io edit` on the first legacy entry):

```
[WARN] topics       subber: 1 legacy `topic: /...` entry in /path/to/subber/sb.module.yaml (sb 0.5.0 reads it as `key:`; same wire key)
                    sub "hello": topic: /dev01/demo/pubber/zenoh/hello -> key: dev01/demo/pubber/zenoh/hello
                    rewrite: `sb io edit hello --module subber`
```

`sb io edit <name>` with no flags regenerates that one entry's file and,
because the manifest holds legacy entries, writes it back with every
one of them stored as `key:`, printing
`  rewrote N legacy topic entry|entries as key: in <path>`. Any other
`sb io` command that writes the manifest does the same, and
`sb io update <module>` reports it on its module line
(`; rewrote N legacy topic entr(y/ies) as key:`).

Like `unity targets`, the row **warns, never fails**: the exit code is
untouched. With no active workspace there is nothing to scan, and the
row is `[SKIP]`. A module whose manifest cannot be read is skipped
here; other checks and commands report that failure.

### 4.11 `workspace` and `ws *` (sb 0.5.0+)

```
[SKIP] workspace    no active workspace
```

The rows `sb ws check` prints ([sbcli_ws.md](sbcli_ws.md) §5.3), for
the active workspace:

| Row | `[OK]` shows | Problem tag | Reports |
|---|---|---|---|
| `workspace` | name, module count, source (URL or repo `sb.flow.yaml`, or `no source`) | `[FAIL]` | the installed copy, or the vault root, cannot be read |
| `ws modules` | every module manifest parses | `[FAIL]` per module | ``no module manifest at <path> (run `sb init` in the module)``, an empty file, a parse error, or (sb 0.7.0+) `module manifest sb.module.yaml not found at <dir>; sb.dev.yml is no longer read since 0.7.0, rename it (see sbcli_module.md §Migrating)` |
| `ws types` | how many typed entries resolve | `[FAIL]` per entry | a proto / fb `type:` that is not in the configured vault nor an `iox2_variants` name |
| `ws instances` | instance count | `[FAIL]` per duplicate | an instance id declared twice for one module |
| `ws encoding` | how many wire keys agree | `[FAIL]` per wire key | entries on one key, across modules, that disagree on `encoding:` |
| `ws io files` | how many generated files exist | `[WARN]` per module | generated files missing under the io dir, with ``run `sb io update <module>` `` |
| `ws requires` (sb 0.6.0+) | `all required tools present` | `[FAIL]` | `<module>: missing <bin>[, <bin>]` per module, joined by `; ` |
| `ws platforms` (sb 0.6.0+) | `all modules support this host` | `[WARN]` | `<module>: not supported on <os>-<arch> (declares: linux, windows)` |
| `ws wires` (sb 0.6.0+) | `<n> wire(s) resolve`, or `no wires` | `[FAIL]` | `<lhs>: <reason>`, reasons below |
| `deprecated` (sb 0.6.0+) | `nothing deprecated in use` | `[WARN]` | one leftover pre-0.6.0 file per line, below |
| `ws source` | the installed copy is current | `[WARN]`; `[SKIP]` with no `source:` | the repo `sb.flow.yaml` is newer than the installed copy (``run sb install``) |

A module that fails `ws modules` is left out of the rows below it.

**`ws requires`** looks up every executable a module's merged `requires:`
names for this host ([sbcli_module.md](sbcli_module.md) §7) on `PATH`.
A module whose `platforms:` does not list this host is skipped, not
failed. A module without `requires:` passes, so a workspace that
declares none reads `all required tools present`.

```
[FAIL] ws requires  ips_detect: missing cmake, clang; ips_viz: missing docker
```

**`ws platforms`** names every module whose `platforms:` block does not
list this host ([sbcli_module.md](sbcli_module.md) §6.2). It only warns:
`sb up` skips such a module, which is the intended behavior on a host
it does not target.

```
[WARN] ws platforms ips_cam_gcam_pub: not supported on windows-x86_64 (declares: linux)
```

**`ws wires`** checks each `wires:` line of the flow
([sbcli_ws.md](sbcli_ws.md) §4.7) against the modules' manifests and
instances. `<lhs>` is the wire's key, `<module>.<entry>`; `<reason>` is
one of:

| Reason | Meaning |
|---|---|
| `unknown subscriber module` | the key's module is not in the workspace |
| `no subscriber <entry> in <module>` | that module has no subscriber of that name |
| `unknown publisher module` | the value's module is not in the workspace |
| `no publisher <entry> in <module>` | that module has no publisher of that name |
| `[*] on iceoryx2 is not supported` | fan-in from every instance needs Zenoh |
| `{id} but <module> has no instances` | `[{id}]` names a publisher without instances |
| `transport mismatch (<a> vs <b>)` | subscriber and publisher entries use different transports |
| `type mismatch (<a> vs <b>)` | subscriber and publisher entries use different message types |

```
[FAIL] ws wires     ips_track.markers: [*] on iceoryx2 is not supported
```

**`deprecated`** (sb 0.7.0+) lists every file from before 0.6.0 that
the workspace still holds, one per line. `sb 0.7.0+` reads or runs none
of them, so each line ends `is ignored since 0.7.0 (see sbcli_module.md §Migrating)`:

```
[WARN] deprecated   sb.dev.yml at /home/el/ws_ips/modules/ips_track/sb.dev.yml is ignored since 0.7.0 (see sbcli_module.md §Migrating)
                    runscript.bash at /home/el/ws_ips/modules/ips_track/runscript.bash is ignored since 0.7.0 (see sbcli_module.md §Migrating)
                    flow.yaml at /home/el/ws_ips/flow.yaml is ignored since 0.7.0 (see sbcli_module.md §Migrating)
```

The items it reports are `sb.dev.yml at <path>`, `flow.yaml at <path>`,
`runscript.bash at <path>`, and `stopscript.bash at <path>`. The row
warns, never fails: an ignored file breaks nothing by itself, and
deleting it (or translating it, [sbcli_module.md](sbcli_module.md) §11)
clears the line. What does fail is a module whose **only** manifest is
still the pre-0.6.0 one: `ws modules` reports it with the rename error
in the table above. A top-level `instances:` map is no longer an item
here either: a flow that has one does not load at all
([sbcli_ws.md](sbcli_ws.md) §8).

Unlike `topics`, a **`[FAIL]` here fails doctor**: a missing module, an
unknown type, a duplicate instance id, an encoding disagreement, a
missing build tool, or a wire that resolves to nothing breaks `sb up`
or codegen, so it counts toward the exit code. Missing generated files
and a stale installed copy are fixed by one command each
(`sb io update`, `sb install`), and an unsupported host or an ignored
leftover file breaks nothing, so those only warn. Types are checked
against the configured vault (`messages_root`), the one `sb install`
imports into, even when doctor's `message styles` row describes a vault
discovered from the current directory.

---

## 5. Exit code and error reporting

```bash
$ sb doctor
sb <version>
[OK]   protoc       ...
[FAIL] flatc        /opt/flatc/dead (file not found)
[OK]   transports   ...
[OK]   libzenohc    ...
[OK]   libiceoryx2  ...
[OK]   tmux         ...
[OK]   message styles ...
[WARN] unity targets generated C# Unity cannot compile:
                    ...
[OK]   config keys  no deprecated keys
[OK]   std vault    ...
[OK]   topics       ...
error: 1 check(s) failed
$ echo $?
1
```

The error line goes to **stderr** (consistent with the rest of the
CLI). Stdout has the checklist; stderr has the summary. Pipe stdout
to a parser without losing the failure signal.

Multiple failures count separately:

```
error: 3 check(s) failed
```

There's no `--quiet` flag; doctor always prints the full checklist.
Wrap it for CI:

```bash
sb doctor > /dev/null || { echo "host needs setup"; exit 1; }
```

---

## 6. Examples

### 6.1 Fresh dev box, nothing configured

```
$ sb doctor
sb <version>
[SKIP] protoc       not set in sb.config.yml
[SKIP] flatc        not set in sb.config.yml
[OK]   transports   zenoh 1.9.0, iceoryx2 0.9.3 (linked into this sb)
[SKIP] libzenohc    not set in sb.config.yml
[SKIP] libiceoryx2  not set in sb.config.yml
[SKIP] tmux         not set in sb.config.yml
[OK]   message styles /home/user/.swarmbotix/messages
                    ros2         138 msg  NOT COMPILED — run `sb message compile --style ros2`
[OK]   unity targets no stale generated C# in a Unity tree
[OK]   config keys  no deprecated keys
[FAIL] std vault    /home/user/.swarmbotix/messages/ros2/message_definitions/std missing 8 expected file(s) (run `sb message list` to install)
[SKIP] topics       no active workspace
error: 1 check(s) failed
```

Recovery: `sb message list` (auto-installs) + edit
`~/.swarmbotix/sb.config.yml` to point at the installed tools (see
[sbcli_config.md](sbcli_config.md) §6).

### 6.2 Fully-configured dev box

```
$ sb doctor
sb <version>
[OK]   protoc       /opt/protobuffer/protoc-35.0-linux-x86_64/bin/protoc (libprotoc 35.0)
[OK]   flatc        /opt/flatbuffers/Linux.flatc.binary.g++-13/flatc (flatc version 25.12.19)
[OK]   transports   zenoh 1.9.0, iceoryx2 0.9.3 (linked into this sb)
[OK]   libzenohc    /opt/zenoh-c/current/lib/libzenohc.so (v1.9.0, dlopen OK)
[OK]   libiceoryx2  /opt/iceoryx2/current/lib/libiceoryx2_ffi_c.so (v0.9.3, dlopen OK)
[OK]   tmux         /usr/bin/tmux (tmux 3.4)
[OK]   message styles /home/el/.swarmbotix/messages
                    ros2         138 msg  targets built
                    swarmbotix    14 msg  targets built
[OK]   unity targets no stale generated C# in a Unity tree
[OK]   config keys  no deprecated keys
[OK]   std vault    /home/el/.swarmbotix/messages/ros2/message_definitions/std populated
[OK]   topics       no legacy `topic: /...` entries in the active workspace
```

Exit code 0. This is the expected steady state.

### 6.3 Tool moved or upgraded out from under sb.config.yml

```
$ sb doctor
sb <version>
[OK]   protoc       /opt/protoc/bin/protoc (libprotoc 35.0)
[FAIL] flatc        /opt/flatc-old/bin/flatc (file not found)
...
error: 1 check(s) failed
```

The `flatc:` entry still points at a directory the user deleted.
Fix:

```bash
sb config set flatc /opt/flatc-new/bin/flatc
sb doctor
```

### 6.4 Loadable file, wrong version

```
$ sb doctor
sb <version>
...
[OK]   transports   zenoh 1.9.0, iceoryx2 0.9.3 (linked into this sb)
[WARN] libiceoryx2  /opt/iceoryx2/v0.9.0/lib/libiceoryx2_ffi_c.so (v0.9.0, dlopen OK)
                    sb links iceoryx2 0.9.3, this library is 0.9.0.
                    Segments are opened on exact version equality, so C/C++ consumers built
                    against this library will get VersionMismatch and an empty topic list.
                    Fix: sb config set libiceoryx2 <path to a 0.9.3 install>
```

The `.so` loads cleanly, so `dlopen` has nothing to say about it; what
disagrees is the version, which doctor reads off the install and
compares with §4.9. Exit code stays 0 — `sb` works, the C/C++ consumers
built against that library do not. Fix:

```bash
sb config set libiceoryx2 /opt/iceoryx2/current/lib/libiceoryx2_ffi_c.so
sb doctor
```

### 6.5 CI gating

```yaml
- name: Validate host
  run: sb doctor

- name: Build
  run: cargo build --release
```

Doctor's non-zero exit fails CI early with a clear list of what's
wrong, before the multi-minute Rust build kicks off.

---

## 7. Configuration interactions

Doctor reads the **merged** config (env override → workspace →
global → built-in defaults), same as every other verb. To diagnose
which file populated each field:

```bash
SB_CONFIG=/tmp/scratch.yml sb doctor      # uses /tmp/scratch.yml as the highest-priority layer
```

vs.

```bash
sb doctor                                  # only the global ~/.swarmbotix/sb.config.yml
```

There's currently no `sb doctor --explain` mode that prints the
source-of-each-field. The layering is documented in
[sbcli_config.md](sbcli_config.md) §3 and the
`sb_config::ConfigSources` type tracks it internally; that data just
isn't surfaced through doctor's output yet.

---

## 8. What doctor doesn't check

By design (the L1 spec) doctor only validates the tooling that L1+
sb itself shells out to. Not validated:

- **Rust toolchain.** Cargo's own checks run when the user's project
  builds. sb itself is a single binary; the user's Rust toolchain
  isn't on the critical path for `sb` to function.
- **Python interpreter / packages.** `sb message new` doesn't shell
  out to Python; doctor doesn't either. The L3 examples activate
  conda explicitly. A `sb doctor` flag to check
  `pip show eclipse-zenoh` is planned but not shipped.
- **Flutter / Dart toolchain.** Same.
- **Package-manager copies of the transports.** The version comparison
  in §4.3 / §4.4 covers the native libraries named in the config. It
  says nothing about what `pip show iceoryx2` reports in whichever
  environment happens to be active, which must match the same number
  for Python consumers to see `sb`'s topics.
- **Network connectivity.** Zenoh's runtime discovery needs the
  network; doctor never opens a Zenoh session.
- **Shared-memory permissions.** iceoryx2's runtime needs
  `/dev/shm` writability; doctor doesn't probe.
- **Generated code freshness.** Doctor doesn't compare
  `<targets>/` mtimes against `<defs>/` mtimes. Use
  `sb message compile` to refresh.
- **Other workspaces.** The workspace rows (sb 0.5.0+, §4.11)
  validate the **active** workspace only. Workspaces that are installed
  but not active are not checked; `sb ws check <name>` covers one of
  them.

---

## 9. Edge cases and gotchas

### 9.1 tmux's `-V` quirk

The first L1 implementation used `--version` for tmux; that triggered
the help text on older tmux builds and the version-extraction regex
failed. The L1 report notes this caught during the first end-to-end
run; the fix (using `-V`) is locked in by
`crates/sb-cli/tests`.

### 9.2 First-line stdout assumption

Doctor extracts the first line of `<tool> --version`'s stdout as the
details column. Tools that print a banner before the version (rare)
would show the banner instead. None of the L1-required tools do
this, but if you swap in an exotic protoc / flatc fork, the column
might look odd. No correctness issue — exit code still reflects
truth.

### 9.3 Tool path with spaces

`Command::new(<path>)` accepts paths with spaces, but the details
column's free-form formatting may look strange:

```
[OK]   protoc       /home/user/With Spaces/bin/protoc (libprotoc 35.0)
```

Cosmetic only; the check itself is fine.

### 9.4 `libloading` dlopen errors are sometimes terse

Some platforms return only "image not found" on dlopen failure, even
when the file does exist (e.g. when transitive deps are missing).
The details column reproduces what libloading gives us — debugging
might need `ldd <path>` to see the actual missing deps.

### 9.5 std vault check predates fresh-install

If `<sb_home>` is brand-new and you've never run any `sb` command,
`<message_definitions>/std/` doesn't exist yet. The std-vault check
reports the miss. Either run `sb message list` (which installs) or
just run `sb doctor` again — it has no install side effect on its
own, only the diagnostic.

### 9.6 No retry / sleep / network probe

Doctor runs each check **once**, synchronously, with no retries.
Transient errors (a tool whose binary is paged out mid-`--version`,
extremely rare) would surface as a one-off FAIL. Re-run if you
suspect noise.
